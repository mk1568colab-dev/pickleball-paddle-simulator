# Pickleball Paddle Simulator

Hosted-ready Streamlit classroom simulator with:

- `admin` and `team_leader` accounts
- SQLite persistence
- quantitative OM/SCM gameplay
- Stage A portfolio and lifecycle logic
- Stage B development pipeline, technology generations, retirement, and cannibalization
- Stage C product-level forecasting, S&OP discipline, cash control, and borrowing
- one shared hosted app instance for classroom use

This version intentionally excludes `team_member`, marketing, ambassador strategy, retailer negotiation, multi-country operations, and Monte Carlo systems.

## Stage C Overview

Stage C upgrades the simulator from a portfolio-and-pipeline business into a portfolio-and-pipeline business that also has to forecast demand, align plans, and survive cash pressure.

Each team now manages:

- up to 3 active product slots: `A`, `B`, `C`
- up to 2 development project slots: `P1`, `P2`
- product-level demand forecasts for each active slot
- firm-level liquidity and borrowing decisions

The core Stage C ideas are:

- active products still compete in the market each round
- future products require investment before they can launch
- launch timing is delayed by readiness and earliest-launch rules
- technology generations affect market attractiveness
- older products can be retired or replaced
- newer products can cannibalize older products within the same team portfolio
- teams now submit product-level forecasts before they plan production
- the simulator now tracks forecast error, bias, and WAPE
- cash, short-term debt, interest expense, and working-capital pressure now matter

## First-Run Admin Setup

The default production workflow does not rely on shared seeded passwords.

When the app starts:

1. If there is no active `admin` account in the database, the app redirects to `Initial Setup`
2. The instructor creates the first admin account with:
   - admin username
   - admin password
   - confirm password
3. After that, normal login becomes available

The initial setup page disables itself automatically after the first active admin exists.

## Local Run

From this project folder:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Then open the URL Streamlit prints, usually:

```text
http://localhost:8501
```

`localhost` is for your own machine only. For classroom use across many student devices, deploy the app to one hosted URL.

## Hosted Run

This project is designed for one centrally hosted Streamlit instance. Students open that hosted URL in their browsers from school Wi-Fi, conference Wi-Fi, or cellular data.

Included host-ready files:

- `run_streamlit.py`
- `Procfile`
- `render.yaml`
- `.streamlit/config.toml`

Typical hosted startup command:

```bash
python run_streamlit.py
```

For a small host like Render:

1. Push this repo to GitHub
2. Create a web service or blueprint from the repo
3. Attach one persistent disk
4. Set a persistent SQLite path such as `/var/data/simulator.db`
5. Start the app with `python run_streamlit.py`

## Environment Variables

Supported environment variables:

- `SIMULATOR_DB_PATH`
  Sets the exact SQLite database file path
- `SIMULATOR_DATA_DIR`
  Sets the directory where `simulator.db` should be created
- `SIMULATOR_ENV`
  Use `prod` or `dev`
- `SIMULATOR_ENABLE_DEMO_ACCOUNTS`
  Only used in explicit development or demo mode
- `RENDER_DISK_PATH`
  Optional hosted disk directory fallback

Database path resolution order:

1. `SIMULATOR_DB_PATH`
2. `SIMULATOR_DATA_DIR/simulator.db`
3. `RENDER_DISK_PATH/simulator.db`
4. local fallback `data/simulator.db`

SQLite is appropriate for one small hosted app instance with one database file. This version is not intended for multiple app replicas sharing SQLite.

## Account Workflow

### Create The First Admin

- Launch the app
- Complete `Initial Setup`
- Sign in with the admin account you just created

### Create Team Leader Accounts

- Log in as `admin`
- Open `Admin User Management`
- Use `Create User`
- Set:
  - `username`
  - temporary password
  - role = `team_leader`
  - `team_name`
  - active or inactive status

### Reset A Password

- Log in as `admin`
- Open `Admin User Management`
- Edit the existing user
- Enter a new temporary password
- Save the account

Passwords are hashed in the database and cannot be viewed later.

### Change Your Own Password

Any logged-in `admin` or `team_leader` can open `My Account` and change their own password by entering:

- current password
- new password
- confirm new password

## Classroom Workflow

1. Instructor completes the initial admin setup
2. Instructor creates or bulk imports `team_leader` accounts
3. Teams log in from their own browsers
4. Instructor updates the `Public Market Report`
5. Teams submit firm-level operations, product-slot plans, product-level forecasts, and development-project decisions in `Team Decisions`
6. Instructor reviews the validation summary for infeasibility, forecast gaps, and likely cash shortfalls, then runs the round from `Instructor Panel`
7. Class reviews aggregate team results, product results, forecast accuracy, liquidity status, and pipeline status in `Results Dashboard`

## Stage C Decision Model

Each team now submits three layers of decisions.

### Firm-Level Shared Decisions

These still apply across the whole firm:

- `overtime_capacity_units`
- `capacity_expansion_units`
- `raw_material_order_qty`
- `supplier_mix_offshore_pct`
- `supplier_mix_balanced_pct`
- `supplier_mix_premium_pct`
- `expedited_order_share_pct`
- `max_backorder_units`
- `planned_borrowing_amount`

These remain shared across all active products for the team.

### Product-Level Active Portfolio Decisions

Each active slot submits:

- `product_name`
- `is_active`
- `target_segment`
- `forecast_units`
- `selling_price_per_unit`
- `planned_production_units`
- `qc_budget_per_unit`
- `target_finished_goods_inventory`
- `retire_flag`

### Development Project Decisions

Each project slot can submit:

- `project_name`
- `target_segment`
- `target_tech_generation`
- `intended_slot_name`
- `planned_launch_round`
- `investment_this_round`
- `testing_intensity`
- `launch_now`
- `cancel_now`
- `cannibalization_group`
- `projected_base_defect_modifier`
- `projected_demand_fit_modifier`

## Lifecycle Rules

Every active product has:

- `age_in_rounds`
- `lifecycle_stage`

Lifecycle stage is currently rule-based and transparent:

- `launch`: age `0-1`
- `growth`: age `2-3`
- `maturity`: age `4-6`
- `decline`: age `7+`

Lifecycle affects:

- demand attractiveness
- price tolerance
- defect stabilization

## Technology Generation Rules

Products and projects now carry a numeric technology generation, currently `Gen 1` to `Gen 4`.

The market report now also includes:

- `current_market_generation`
- `technology_shift_rate`
- `premium_tech_adoption`
- `mid_market_tech_adoption`
- `beginner_price_pressure`

Technology affects:

- demand attractiveness
- obsolescence pressure
- launch risk for newer products
- relative price tolerance

The effect is stronger in premium and mid segments than in beginner.

## Launch Readiness Rules

Development projects now progress over multiple rounds.

Each project has:

- `required_investment`
- `cumulative_investment`
- `launch_readiness_score`
- `planned_launch_round`
- `earliest_launch_round`
- `status`

Readiness is driven by:

- cumulative investment progress
- testing intensity
- technology complexity penalty

In the engine, a project becomes `launch_ready` only when:

- `cumulative_investment >= required_investment`
- `launch_readiness_score >= launch threshold`
- `current round >= earliest_launch_round`

Even after becoming `launch_ready`, the team still has to choose `launch_now` to actually launch it.

Only one launch per team per round is allowed in Stage B.

## Retirement And Replacement Rules

Teams can retire aging products with `retire_flag`.

Stage B also supports replacement:

- when a project launches into an occupied slot, it replaces the old product in that slot
- replaced inventory is liquidated at a markdown recovery rate
- the new product starts with:
  - lifecycle stage `launch`
  - age `0`
  - its project tech generation
  - its projected defect and demand-fit modifiers

Retired products no longer remain active in future rounds.

## Cannibalization Logic

Stage B models bounded intra-team cannibalization after initial market demand allocation.

Demand can transfer from an older product to a newer product when:

- both belong to the same team
- they are in the same cannibalization group or similar segment
- the receiving product is newer, stronger, or just launched
- the donor product is more mature or declining

Cannibalization is intentionally conservative and transparent. The engine stores:

- demand shifted in
- demand shifted out
- total team-level cannibalized demand

## Forecasting And S&OP Logic

Each active product now carries its own submitted demand forecast.

After the round runs, the simulator compares forecast and realized product demand using:

- `forecast_error_units = actual_demand_units - forecast_units`
- `absolute_error_units = abs(actual_demand_units - forecast_units)`
- `forecast_bias_pct = forecast_error_units / max(forecast_units, 1)`
- per-product `mape_or_wape_value = absolute_error_units / max(actual_demand_units, 1)`
- team-level `forecast_wape = sum(absolute_error_units) / max(sum(actual_demand_units), 1)`

The Team Decisions preview and Instructor Panel now surface planning-discipline warnings such as:

- production plan materially below forecast
- production plan materially above forecast
- raw-material ordering too low for the planned output
- high inventory target relative to forecast
- likely cash shortfall even before the round is executed

## Cash And Borrowing Logic

Stage C keeps finance intentionally simple and classroom-manageable.

The simulator now rolls forward:

- `cash_balance`
- `short_term_debt_balance`
- `interest_expense`
- `working_capital_requirement`
- `liquidity_stress_flag`

Round cash flow is modeled as:

- starting cash
- plus revenue collected
- plus planned borrowing
- minus procurement spend
- minus production conversion spend
- minus holding cost
- minus warranty cost
- minus backlog cost
- minus expansion capex
- minus development investment
- minus interest expense

If ending cash would go negative, the engine automatically creates short-term debt for the remaining deficit and floors cash at zero.

Liquidity stress is flagged when combinations of low cash, high debt, repeated borrowing, or heavy working-capital burden appear. The impact is intentionally modest.

## Stage C Engine Logic

The engine still keeps capacity, raw materials, backlog, reputation, and cash at the team level, but now runs demand, forecast accuracy, and results at the product level.

### Shared Firm Constraints

For each team, the simulator first calculates:

- installed capacity
- overtime-adjusted effective capacity
- raw-material inventory available this round
- inbound raw-material receipts
- weighted supplier cost, lead time, defect pressure, and risk exposure

### Project Progress

Before demand allocation, the engine:

- updates each project's cumulative investment
- recomputes launch readiness
- updates project status
- checks launch eligibility

### Launch And Replacement

If an eligible project is launched:

- the target slot becomes a new active product
- any replaced product in that slot is retired
- the new product inherits the project tech generation and modifiers
- the launched product starts in lifecycle stage `launch`

### Product-Level Production Allocation

Teams still submit product-level planned production by slot.

If the sum of product plans exceeds firm-level feasible production because of:

- capacity
- overtime limit
- raw-material availability

the engine proportionally caps production across the active products using largest-remainder integer rounding.

### Product-Level Defect Rate

Each product's defect rate now depends on:

- archetype base defect rate
- product `base_defect_rate_modifier`
- product `qc_budget_per_unit`
- shared supplier defect pressure
- supply risk
- utilization stress
- launch instability
- technology novelty penalty when appropriate

### Product-Level Demand Allocation

Demand is split into:

- premium
- mid
- beginner

Each active product competes for segment demand using:

- actual numeric selling price
- target segment alignment
- archetype segment fit
- product demand-fit modifier
- lifecycle multiplier
- team reputation
- service readiness
- technology generation relative to the market
- launch novelty when newly launched

Demand is allocated across all active products from all teams, not only at the team level.

### Cannibalization Pass

After initial demand allocation, the engine applies bounded intra-team cannibalization so a newer or stronger product can steal part of an older sibling product's demand.

### Product-Level Service And Inventory

Each product now has its own:

- beginning finished-goods inventory
- beginning backlog
- demand allocated
- sales units
- lost sales units
- ending finished-goods inventory
- fill rate
- profit contribution

Backorders remain constrained by the shared firm-level `max_backorder_units`.

### Team-Level Aggregation

After product results are computed, the engine aggregates them into a firm-level summary:

- total sales
- total revenue
- total cost
- total profit
- weighted defect rate
- fill rate
- ending total inventory
- ending raw-material inventory
- updated reputation
- updated cash
- updated installed capacity
- innovation investment
- launch and retirement event text
- forecast totals and forecast accuracy metrics
- ending cash, debt, interest, and working-capital burden

## Team Decisions Page

The `Team Decisions` page now has six main parts:

1. team identity
2. current team state
3. firm-level shared decisions and finance
4. active product portfolio and forecasts
5. development pipeline
6. analytics preview before save

The preview now shows:

- total forecast units
- total planned production across products
- forecast-production gap
- effective firm capacity
- raw-material sufficiency
- projected ending inventory if forecast is accurate
- projected working-capital burden
- projected ending cash before borrowing
- projected likely borrowing need
- projected portfolio mix by segment
- projected weighted defect rate
- projected weighted margin by product
- pipeline project count
- launch-ready project count
- average portfolio tech position versus market generation
- products at risk of obsolescence
- likely cannibalization exposure
- warnings when production exceeds shared constraints

## Results Dashboard

The dashboard now shows active portfolio, pipeline, forecast accuracy, and liquidity outputs.

### Admin View

- team-level ranking tables
- product-level results table
- forecast accuracy and planning-diagnostic tables
- liquidity and debt summary
- active portfolio snapshot by team
- lifecycle stage distribution
- development pipeline table
- launch and retirement log
- persistent team state

### Team Leader View

- own team aggregate results
- own forecast-vs-actual detail
- own cash and debt summary
- own active portfolio snapshot
- own development pipeline table
- own product results
- own launch and retirement events
- public ranking table

## Database Schema

The SQLite database now contains these main tables:

- `users`
  username, password hash, role, team assignment, and active status
- `team_archetypes`
  archetype baselines plus suggested default portfolios
- `market_reports`
  public round conditions plus technology-shift fields
- `team_decisions`
  firm-level shared portfolio constraints and planned borrowing by round
- `product_lines`
  persistent slot state for each team's active or retired products
- `product_decisions`
  product-slot decisions and per-product forecasts by round
- `product_forecasts`
  persisted product-level forecast submissions by round
- `product_development_projects`
  persistent development-pipeline slots and launch state
- `team_states`
  persistent team cash, debt, materials, capacity, reputation, backlog, and cumulative profit
- `round_results`
  aggregate firm-level round results including forecast and finance metrics
- `product_round_results`
  product-slot round results including launch, retirement, cannibalization, and forecast metrics
- `forecast_accuracy_results`
  per-product forecast-vs-actual diagnostics by round

## Roles And Access

`admin` can use:

- `Home`
- `Public Market Report`
- `Team Decisions`
- `Instructor Panel`
- `Results Dashboard`
- `Admin User Management`
- `My Account`

`team_leader` can use:

- `Home`
- `Public Market Report` as read-only
- `Team Decisions` for their own assigned team only
- `Results Dashboard` with safe filtered visibility
- `My Account`

`team_leader` cannot:

- run rounds
- reset runtime data
- manage users
- submit decisions for another team

## Security Notes

- passwords are stored only as secure hashes
- existing passwords are never displayed after creation
- inactive users cannot log in
- page guards protect admin-only controls
- `team_leader` team assignment comes from the authenticated account, not from a manual text field

## Demo Accounts

Production mode does not create shared default passwords.

Demo accounts are seeded only when both of these are true:

- `SIMULATOR_ENV=dev`
- `SIMULATOR_ENABLE_DEMO_ACCOUNTS=true`

That option exists only for explicit demo or development use.

## Simplifications Left For Later Stages

Stage C intentionally still does not include:

- marketing
- ambassador strategy
- retailer or channel negotiation
- multi-country operations
- patent or IP systems
- complex stochastic Monte Carlo simulation
- delayed channel rollout by geography
- full financial statements
- taxes, equity issuance, or advanced treasury management

This keeps the model classroom-manageable while still adding real portfolio, pipeline, forecasting, cash-control, and replacement tradeoffs.
